#ifndef __P_TYPE_H__
#define __P_TYPE_H__

#include "common_type.h"

#endif
